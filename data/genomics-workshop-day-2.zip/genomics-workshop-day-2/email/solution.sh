while read name
do
    sed "s/FRIEND/$name/g" email.template > emails/$name
done < friends.txt 
